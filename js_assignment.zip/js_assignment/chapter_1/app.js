// task 1
alert('Hello World');

// task 2
alert('Error! Please enter a valid Password.');

// task 3
alert('Welcome to JS Land... \r\nHappy Coding!');

// task 4
alert('Welcome to JS Land...');
alert('Happy Coding!');

// task 5
alert("Hello I can run js through my web browser's console");
