var age = 22;
alert('I am ' + age + ' years old.');