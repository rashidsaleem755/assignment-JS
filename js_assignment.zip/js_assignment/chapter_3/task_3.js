var birthYear;
birthYear = 1999;