var item = 'Pizza';
for(var i = length.item; i < 0; i--){
    for(var j = i; j >= i; j--){
        console.log(j);
    }
    console.log("\n");
}

