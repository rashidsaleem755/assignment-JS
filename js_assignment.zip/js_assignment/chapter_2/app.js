// task 1
var username;

// task 2
var myName = 'Nabeel Khatri';

// task 3
var message;
message = 'Hello Wolrd';
alert(message);

// task 6
var email = 'nabeelkhatri12@gmail.com';
alert('My email address is ' + '' + email);

// task 7
var book = 'A Smarter Way to Learn JavaScript';
alert('I am trying to learn from the Book ' + '' + book);

// task 9
var value = '“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”';
alert(value);
