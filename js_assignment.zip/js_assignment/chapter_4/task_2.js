// legal vairables
var name;
var cOurse;
var name_;
var last_Name;
var age;

// illegal
var Name;
var \name;
var /cost;
var Age;
var -course;